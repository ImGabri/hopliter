# Hopliter Cline handoff

Open the extracted `hopliter` folder in VS Code with Cline. Ask Cline to read this file and `README.md` before editing. The full visible conversation is in [conversation/TRANSCRIPT.md](conversation/TRANSCRIPT.md) with its uploads and earlier downloads in [conversation/attachments](conversation/attachments/).

The runnable Java 21 JAR is `HeldItemUidFixture.jar`. The 1.2.0 upgrade adds preview and final inventory verification for the single-copy and experimental ×4 fixture on authorized staging. If Paper shortens a snapshot, the optional read-only bridge under `paper-bridge/` returns the full inventory data. See the README for local build and staging setup. The integration harness uses a Unix PTY, so Windows users can run it in WSL.

The published baseline is commit `106fa4d757a90a66fb884b4dd92f3dd53781f6f9`. This archive carries the subsequent local upgrade. [GitHub repository](https://github.com/ImGabri/hopliter)

## Verification

- The Maven build and 19 simulator tests passed.
- Local Paper 1.21.11 build 132 passed preview and single copy, ×4 with matching typed UIDs, insufficient capacity with zero writes, source changes stopping the batch, detection of a rewritten UID in the final snapshot, and disconnect after the second write with zero-write recovery.
- The independent TradeCheck reference passed 20 offline tests and 10 scripted scenarios.
- Hoplite's live backend, actual UID schema, and proprietary detector behavior still require separate authorized staging validation.

## Investigating a suspected duplicate

Use the fixture on a disposable staging server as a positive control. Record the exact UID field and type, the number of item units, and the detector result separately. The local Paper integration used the synthetic path `minecraft:custom_data.hopliter_test_uid`. The staging operator supplies the actual UID path.

Use [TradeCheck](reference/TradeCheck/README.md) to investigate spontaneous duplication. Start from a known tagged batch, then count item units across inventories, escrow, refunds, ground drops, backpacks, and vaults. Check for one terminal trade settlement. Compare the first unexpected count or destination to a normal full-inventory overflow run. Include cancellation, retry, disconnect, and storage reload scenarios in staging. Keep intentionally seeded UID matches separate from evidence that a normal trade created an extra item.

## Hoplite side note

Hoplite's public site advertises Java 1.21.11 and Bedrock access. The October 23 notes mention obtaining recipe scrolls through Zombie Survival trades. The November 6 notes mention an eight-slot Personal Vault, a backpack booster change, and dupe detection fixes. [Hoplite](https://www.hoplite.gg/) · [October 23 notes](https://www.hoplite.gg/news/patch-notes-oct-23rd-2026) · [November 6 notes](https://www.hoplite.gg/news/patch-notes-nov-6th-2026)
