"""Run the executable against an operator's disposable loopback Paper test player."""

import argparse
from contextlib import contextmanager
from getpass import getpass
import re
import socket
import socketserver
import struct
from tempfile import TemporaryDirectory
from threading import Thread

from test_fixture import JAR, launch, response


def read_frame(stream):
    prefix = stream.read(4)
    if not prefix:
        raise EOFError("RCON connection closed")
    length, = struct.unpack("<i", prefix)
    if not 10 <= length <= 65_536:
        raise ValueError("Invalid RCON frame size")
    payload = stream.read(length)
    if len(payload) != length or payload[-2:] != b"\0\0":
        raise EOFError("Incomplete RCON frame")
    request_id, kind = struct.unpack("<ii", payload[:8])
    return prefix + payload, request_id, kind, payload[8:-2]


def require(condition, detail):
    if not condition:
        raise AssertionError(detail)


@contextmanager
def console(port, password):
    with socket.create_connection(("127.0.0.1", port), timeout=5) as connection, connection.makefile("rb") as incoming:
        connection.sendall(response(1, 3, password.encode("utf-8")))
        _, request_id, kind, data = read_frame(incoming)
        if request_id == 1 and kind == 0 and not data:
            _, request_id, kind, data = read_frame(incoming)
        require((request_id, kind) == (1, 2), "Paper rejected the test RCON login")
        sequence = 1

        def command(text):
            nonlocal sequence
            sequence += 1
            connection.sendall(response(sequence, 2, text.encode("utf-8")))
            _, request_id, kind, body = read_frame(incoming)
            require((request_id, kind) == (sequence, 0), "Unexpected RCON response")
            require(len(body) < 4096, "Use a clean, disposable player inventory for this test")
            return body.decode("utf-8")

        yield command


class ForwardRcon(socketserver.StreamRequestHandler):
    def handle(self):
        with socket.create_connection(("127.0.0.1", self.server.paper_port), timeout=5) as paper:
            with paper.makefile("rb") as incoming:
                while True:
                    try:
                        packet, _, kind, body = read_frame(self.rfile)
                    except EOFError:
                        return
                    paper.sendall(packet)
                    reply, _, reply_kind, reply_body = read_frame(incoming)
                    if kind == 2:
                        command = body.decode("utf-8")
                        self.server.commands.append(command)
                        if " run item replace entity " in command:
                            self.server.writes.append(command)
                        if self.server.drop_reply(command, reply_body.decode("utf-8")):
                            return
                    self.request.sendall(reply)
                    if kind == 3 and reply_kind == 0 and not reply_body:
                        self.request.sendall(read_frame(incoming)[0])


class Gateway(socketserver.ThreadingTCPServer):
    daemon_threads = True

    def __init__(self, paper_port):
        super().__init__(("127.0.0.1", 0), ForwardRcon)
        self.paper_port = paper_port
        self.commands = []
        self.writes = []
        self.drop_reply = lambda _command, _reply: False

    def reset(self):
        self.commands.clear()
        self.writes.clear()
        self.drop_reply = lambda _command, _reply: False


@contextmanager
def relay(port):
    with Gateway(port) as gateway:
        worker = Thread(target=gateway.serve_forever, kwargs={"poll_interval": 0.02}, daemon=True)
        worker.start()
        try:
            yield gateway
        finally:
            gateway.shutdown()
            worker.join()


def verify(port, player, password):
    uid_path = "minecraft:custom_data.hopliter_test_uid"
    query = f"data get entity {player} "
    bridge = f"hoplitersnapshot:hopliter-snapshot {player} "
    with console(port, password) as command, relay(port) as proxy, TemporaryDirectory() as state:
        selection = command(query + "SelectedItemSlot")
        require(" has the following entity data: " in selection, "Connect the disposable test player before running")
        require(command(bridge + "Inventory").startswith("HOPLITER_SNBT "), "Install the local Paper snapshot bridge")

        def paper_item(uid):
            return f'minecraft:paper[minecraft:custom_data={{hopliter_test_uid:"{uid}"}}]'

        def seed(uid, count=5):
            reply = command(f"item replace entity {player} weapon.mainhand with {paper_item(uid)} {count}")
            require(reply.startswith("Replaced a slot on "), reply)

        def reset(uid):
            proxy.reset()
            command(f"clear {player}")
            seed(uid)

        def held(uid, count):
            check_item("weapon.mainhand", uid, count)

        def check_item(slot, uid, count):
            reply = command(f"execute if items entity {player} {slot} {paper_item(uid)}")
            require(reply == f"Test passed. Count: {count}", f"{slot} expected {count} of {uid}. Paper replied {reply!r}")

        def run(*args, code=0, expected=()):
            actual_code, output = launch(
                proxy, state, "--uid-path", uid_path, "--uid-type", "string", *args,
                player=player, password=password,
            )
            require(actual_code == code and all(part in output for part in expected), output)

        try:
            reset("fixture-single")
            before = command(bridge + "Inventory")
            run("--preview", expected=("PREVIEW", "Held count = 5", "present on source (string)"))
            require(not proxy.writes and command(bridge + "Inventory") == before, "Preview changed the inventory")
            run(expected=("PASS", "Final matching slots = [inventory.0]", "Matching UID (string) = fixture-single"))
            require(len(proxy.writes) == 1, "Expected one write for the default mode")
            held("fixture-single", 5)
            check_item("inventory.0", "fixture-single", 1)
            print("PASS preview and default single copy")

            reset("fixture-multiply")
            run("--experimental-multiply", "4",
                expected=("Verified copies = 3", "Final matching slots = [inventory.0, inventory.1, inventory.2]"))
            require(len(proxy.writes) == 3, "Expected exactly three writes for ×4")
            held("fixture-multiply", 5)
            for slot in range(3):
                check_item(f"inventory.{slot}", "fixture-multiply", 1)
            print("PASS ×4 with matching typed UIDs")

            reset("fixture-space")
            for slot in range(25):
                reply = command(f"item replace entity {player} inventory.{slot} with minecraft:stone")
                require(reply.startswith("Replaced a slot on "), reply)
            before = command(bridge + "Inventory")
            run("--experimental-multiply", "4", code=3,
                expected=("Need 3 empty main-inventory slots. Found 2.",))
            require(not proxy.writes and command(bridge + "Inventory") == before, "Space rejection changed inventory")
            print("PASS insufficient space sends zero writes")

            reset("fixture-original")
            changed = False

            def change_source_after_readback(text, reply):
                nonlocal changed
                if (not changed and len(proxy.writes) == 1
                        and text in (query + "Inventory[{Slot:9b}]", query + "Inventory[{Slot:9}]")
                        and " has the following entity data: " in reply):
                    seed("fixture-changed", 1)
                    changed = True
                return False

            proxy.drop_reply = change_source_after_readback
            run("--experimental-multiply", "4", code=4,
                expected=("PARTIAL", "Verified copies = 1", "Final matching slots = [inventory.0]"))
            require(changed and len(proxy.writes) == 1, "Source-change test sent an unexpected number of writes")
            held("fixture-changed", 1)
            check_item("inventory.0", "fixture-original", 1)
            run(code=4, expected=("RECOVERY_READBACK", "inventory.0 = 1 × minecraft:paper"))
            require(len(proxy.writes) == 1, "Recovery wrote after the source-change case")
            print("PASS source change stops the batch")

            reset("fixture-final")
            rewritten = False

            def rewrite_after_third_readback(text, reply):
                nonlocal rewritten
                third_slot = any(text == prefix + f"Inventory[{{Slot:11{suffix}}}]"
                                 for prefix in (query, bridge) for suffix in ("b", ""))
                if (not rewritten and len(proxy.writes) == 3 and third_slot
                        and (reply.startswith("HOPLITER_SNBT ") or (
                            " has the following entity data: " in reply and not reply.endswith("...")))):
                    changed_item = command(f"item replace entity {player} inventory.2 with {paper_item('fixture-rewritten')}")
                    require(changed_item.startswith("Replaced a slot on "), changed_item)
                    rewritten = True
                return False

            proxy.drop_reply = rewrite_after_third_readback
            run("--experimental-multiply", "4", code=4,
                expected=("PARTIAL", "Verified copies = 3", "Final missing or changed slots = [inventory.2]"))
            require(rewritten and len(proxy.writes) == 3, "Final snapshot test sent unexpected writes")
            check_item("inventory.2", "fixture-rewritten", 1)
            run(code=4, expected=("RECOVERY_READBACK",))
            require(len(proxy.writes) == 3, "Recovery wrote after the rewritten-copy case")
            print("PASS final snapshot identifies a rewritten UID")

            reset("fixture-disconnect")
            proxy.drop_reply = lambda text, reply: (
                len(proxy.writes) == 2 and " run item replace entity " in text
                and reply.startswith("Replaced a slot on ")
            )
            run("--experimental-multiply", "4", code=4,
                expected=("INCONCLUSIVE", "Verified copies = 1", "Uncertain slot = inventory.1."))
            held("fixture-disconnect", 5)
            for slot in range(2):
                check_item(f"inventory.{slot}", "fixture-disconnect", 1)
            before = command(bridge + "Inventory")
            proxy.commands.clear()
            run("--experimental-multiply", "4", code=4,
                expected=("RECOVERY_READBACK", "inventory.0 = 1 × minecraft:paper", "inventory.1 = 1 × minecraft:paper"))
            require(len(proxy.writes) == 2 and command(bridge + "Inventory") == before, "Recovery changed inventory")
            allowed_reads = {prefix + f"Inventory[{{Slot:{slot}{suffix}}}]"
                             for prefix in (query, bridge) for slot in (9, 10) for suffix in ("", "b")}
            require(all(text in allowed_reads for text in proxy.commands), "Recovery queried outside attempted slots")
            print("PASS disconnect after second write and zero-write recovery")
        finally:
            command(f"clear {player}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=25575, help="loopback RCON port")
    parser.add_argument("--disposable-player", required=True, help="online test player whose inventory may be cleared")
    args = parser.parse_args()
    if not re.fullmatch(r"[A-Za-z0-9_]{3,16}", args.disposable_player) or not 1 <= args.port <= 65_535:
        parser.error("Provide a valid Minecraft Java username and RCON port.")
    if not JAR.is_file():
        parser.error("Build the JAR and set HOPLITER_JAR to its path.")
    verify(args.port, args.disposable_player, getpass("Local Paper RCON password: "))


if __name__ == "__main__":
    main()
