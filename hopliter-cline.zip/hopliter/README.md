# hopliter

Held Item UID Fixture for Minecraft staging tests.

This Java 21 executable copies one unit of the test player's held item to the
first main inventory slot (`inventory.0`) by default. Experimental Multiply
creates a batch of one-unit copies in separate slots. Both modes use the
authenticated staging server console and can verify a UID stored on the item.

## Run on staging

1. Use an existing RCON endpoint on your Java 1.21.11 staging backend, reached
   at localhost or through an SSH tunnel. The default local port is 25575.
2. Log in with the test player and hold a UID-bearing item. Keep the same item
   selected during the run. For the default run, free the upper-left slot of the
   main inventory.
3. Open `HeldItemUidFixture.jar` from any folder with Java 21. In the dialog,
   enter the local port, Java username, and RCON password. Select **Preview only**
   to inspect the plan, then **Run once** to execute a fresh plan.
   Supply the optional UID path and type to get an exact comparison.

For a terminal run, use this command and enter the password when prompted.

```text
java -jar HeldItemUidFixture.jar --host 127.0.0.1 --port 25575 --player TestPlayer
```

## Read-only preview

Add `--preview` to either mode to see the selected hotbar slot, held count,
planned destinations, available space, and whether the configured UID exists
on the source with the requested NBT type. Preview only reads the server and
leaves any recovery journal intact. A subsequent run checks the live state.

```text
java -jar HeldItemUidFixture.jar --player TestPlayer --experimental-multiply 4 --preview
```

## Experimental Multiply

Tick **Experimental Multiply** in the dialog and enter a factor from 1 to 28,
or add `--experimental-multiply N` in the terminal. The factor includes the
original stack. With **×4**, the tool adds three one-unit copies to three
empty main-inventory slots. A held stack of five stays at five. **×1** requests
zero copies.

```text
java -jar HeldItemUidFixture.jar --player TestPlayer --experimental-multiply 4
```

The tool checks for enough free slots before it starts. It uses the captured
hotbar slot as the source, compares the source again before each copy, and
checks the selected hotbar slot and empty destination in the write command.
Each copy is verified from its server-side readback.
The final report separates the copies verified after each write from the
matching items observed together in one final inventory snapshot.

## Verify a UID

UID paths are relative to the item's `components` compound. For example,
append `--uid-path minecraft:custom_data.fixture_uid --uid-type string` to
compare a string stored under the `fixture_uid` key in custom data. Quote
individual path keys that contain dots, such as
`minecraft:custom_data.PublicBukkitValues."demo.plugin:uid"`. Use
`java -jar HeldItemUidFixture.jar --help` for the supported NBT types.

## Interpret the result

| Result | Meaning |
| --- | --- |
| `PASS` | The source was preserved and the requested copies and typed UIDs match in the final snapshot. |
| `PREVIEW` | The plan was read from the server with zero writes. |
| `UID_UNVERIFIED` | The copy data and counts match. Supply a valid UID path and type for a direct UID check. |
| `NO_COPY` | No write was sent. The result explains why. |
| `PARTIAL` | Multiply stopped after confirming at least one copy. The report lists the copies it confirmed. |
| `INCONCLUSIVE` | A write or readback could not be confirmed. The report identifies any uncertain slot. |
| `RECOVERY_READBACK` | The tool inspected the attempted destinations and reported their current contents. |

The tool records each destination before it attempts a write. After a partial
or inconclusive run, reopen this version for the same endpoint and test player.
That run only reads the attempted slots and exits. The readback shows current
contents, so use staging logs to interpret any missing or rewritten copies.

## Build and verify

Build with a JDK 21 and Maven using `mvn clean package`. The Maven build creates
`target/helditem-uid-fixture-1.2.0.jar`. On Linux or macOS, run the simulator
suite against that build.

```bash
HOPLITER_JAR=target/helditem-uid-fixture-1.2.0.jar python3 tests/test_fixture.py
```

The GitHub Actions workflow builds the JAR, runs the simulator against that
artifact, and packages the versioned JAR with `SHA256SUMS`.

### Paper integration

Start a disposable Paper 1.21.11 server with RCON on loopback and connect a
dedicated test player. The harness resets that player's inventory between
cases and at exit. It prompts for the local RCON password.

Install the supplied `paper-bridge/HopliterSnapshot-Paper1.21.11.jar` in the
staging server's `plugins` folder. Paper 1.21.11 folds long `/data get` replies
with an ellipsis. The desktop JAR automatically asks the read-only bridge
for the complete value when it sees that marker. The bridge accepts only
inventory and selected-item reads from the server console.

Build the bridge with JDK 21 from a bootstrapped Paper 1.21.11 server directory.

```bash
bash paper-bridge/build.sh /path/to/local/paper-server
```

The build places the bridge JAR in `paper-bridge/target/`. Run the harness on
Linux, macOS, or WSL with the staging server reachable on loopback.

```bash
HOPLITER_JAR=target/helditem-uid-fixture-1.2.0.jar python3 tests/integration_paper.py \
  --port 25575 --disposable-player FixtureProbe
```

The integration check uses synthetic UID-bearing paper and verifies preview,
single copy, ×4, insufficient space, a mid-run source change, a rewritten
copy detected in the final snapshot, and recovery after a lost response to
the second write. The loopback relay triggers interruptions at the RCON
response boundary.
