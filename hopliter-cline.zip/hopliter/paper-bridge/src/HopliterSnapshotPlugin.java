package com.example.hopliter;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.List;
import java.util.regex.Pattern;
import net.minecraft.commands.arguments.NbtPathArgument;
import net.minecraft.nbt.Tag;
import net.minecraft.server.commands.data.EntityDataAccessor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.command.RemoteConsoleCommandSender;
import org.bukkit.craftbukkit.entity.CraftPlayer;
import org.bukkit.plugin.java.JavaPlugin;

public final class HopliterSnapshotPlugin extends JavaPlugin {
    private static final Pattern FIELD = Pattern.compile(
            "SelectedItem(?:Slot)?|Inventory(?:\\[\\{Slot:(?:[0-9]|[12][0-9]|3[0-5])b?\\}\\])?");

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof ConsoleCommandSender) && !(sender instanceof RemoteConsoleCommandSender)) {
            sender.sendMessage("Use the staging server console.");
            return true;
        }
        if (args.length != 2 || !FIELD.matcher(args[1]).matches()) {
            return false;
        }
        if (!(Bukkit.getPlayerExact(args[0]) instanceof CraftPlayer player)) {
            sender.sendMessage("No entity was found");
            return true;
        }

        String field = args[1];
        try {
            Tag snapshot = new EntityDataAccessor(player.getHandle()).getData();
            List<Tag> values = NbtPathArgument.nbtPath().parse(new StringReader(field)).get(snapshot);
            if (values.size() == 1) {
                // Tag's SNBT string avoids the display-oriented length limit of /data get.
                sender.sendMessage("HOPLITER_SNBT " + values.getFirst());
            } else {
                sender.sendMessage("Expected one inventory value");
            }
        } catch (CommandSyntaxException error) {
            sender.sendMessage("Found no elements matching " + field);
        }
        return true;
    }
}
