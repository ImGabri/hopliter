#!/usr/bin/env bash
set -euo pipefail

project_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
paper_dir=$(cd -- "${1:?Supply the directory of a bootstrapped Paper 1.21.11 server}" && pwd)
if [ ! -d "$paper_dir/versions/1.21.11" ] || [ ! -d "$paper_dir/libraries" ]; then
    printf '%s\n' 'Start the local Paper 1.21.11 server once to prepare its runtime files.' >&2
    exit 1
fi

classpath=''
while IFS= read -r -d '' dependency; do
    classpath="${classpath:+$classpath:}$dependency"
done < <(find "$paper_dir/versions/1.21.11" "$paper_dir/libraries" -type f -name '*.jar' -print0)

build_dir=$(mktemp -d)
trap 'rm -rf -- "$build_dir"' EXIT
mkdir -p "$build_dir/classes" "$project_dir/target"
printf 'Manifest-Version: 1.0\npaperweight-mappings-namespace: mojang\n\n' > "$build_dir/MANIFEST.MF"
javac --release 21 -proc:none -encoding UTF-8 -cp "$classpath" -d "$build_dir/classes" "$project_dir/src/HopliterSnapshotPlugin.java"
jar --create --file "$project_dir/target/HopliterSnapshot-Paper1.21.11.jar" \
    --manifest "$build_dir/MANIFEST.MF" -C "$build_dir/classes" . -C "$project_dir" plugin.yml
printf '%s\n' "$project_dir/target/HopliterSnapshot-Paper1.21.11.jar"
