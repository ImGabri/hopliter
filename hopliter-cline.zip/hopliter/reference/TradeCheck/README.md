# TradeCheck

TradeCheck is an offline regression suite and JSON Lines trace checker for Minecraft trade and backpack behavior. It follows one tagged batch from A to B and reports the first checkpoint where the count, settlement, or expected destination changes incorrectly. The reference model assumes the overflow behavior in the report and can run with Python 3.10+ using the standard library.

## Run on Windows

Extract the ZIP, open a terminal inside the extracted `TradeCheck` folder, and run the suite.

```powershell
py -m tradecheck suite
py -m tradecheck simulate partial-overflow --out trace.jsonl
py -m tradecheck check trace.jsonl
```

Use `python3` in place of `py` on macOS or Linux. Run `py -m tradecheck list` to see the case names.

The partial-overflow run starts with 10 tagged paper in A's inventory and 60 matching paper in B's otherwise full inventory. B gains 4 paper and the ground drop contains 6. The total stays at 70.

```powershell
py -m tradecheck check examples/partial-overflow-ok.jsonl
py -m tradecheck check examples/partial-overflow-duplicate.jsonl
py -m unittest discover -s tests -v
```

The second example deliberately contains four extra paper. Expect `DUPLICATE_UNITS` at `delivery_overflow` and exit code `1`. Add `--json` to `check` for structured output.

## Local cases

| Case | Check |
| --- | --- |
| `normal` | A transfers one paper to B's inventory. |
| `full-overflow` | With B full, the whole batch goes to the expected overflow destination. |
| `partial-overflow` | Four go into the matching stack and exactly six overflow. |
| `full-refund` | A receives one overflow refund even when close and quit both run. |
| `late-confirm` | A confirmation after cancellation leaves the refund settled. |
| `close-after-commit` | Close, quit and another confirmation leave the completed transfer settled. |
| `offer-revision` | The changed offer requires fresh confirmation from both players. |
| `backpack-pickup` | Collection moves paper out of the ground drop and into B's backpack. |
| `backpack-reload` | A standalone backpack save and reload preserves the tagged paper. |
| `delivery-retry` | Pending delivery is consumed once across retries. |

The local model uses capacities for matching stacks and scripted server-side callbacks. Its backpack reload exercises serialization of the fixture. Server coverage comes from exporting the actual trade and backpack implementation on staging.

## Capture a real staging trace

1. Give each run a unique ID and tag the test paper with that ID using a plugin-owned Paper Persistent Data Container key. Use identical tags and matching item data on both stacks for a partial-stack test. Use a separate marker for the Accept control. Verify that your item tag survives the paths you want to test. [Paper PDC guide](https://docs.papermc.io/paper/dev/pdc/) · [ItemStack API](https://jd.papermc.io/paper/1.21.11/org/bukkit/inventory/ItemStack.html#isSimilar(org.bukkit.inventory.ItemStack))
2. Take a baseline before the offer enters escrow. Record completed checkpoints at offer changes, confirmations, settlement, overflow or refund, close or quit, backpack pickup, and reload. Use an event label from the actual handler that ran, such as `delivery_overflow` or `cancel_refund`. Capture an end checkpoint after the last planned action.
3. Read actual tagged quantities from all applicable locations using one consistent server-side snapshot. Use the sum of the stack amounts as your unit count. Count each logical item once when a GUI, live inventory, and persisted record represent the same item. A reserved delivery and its already delivered copy count separately only if both are still independently available to claim.
4. For ground items, use the owner actually assigned by your backend or record `ground_unknown` for public drops. Take the final checkpoint after pickup if ownership is required and the server drops paper without an assigned owner.
5. Run `py -m tradecheck check staging-trace.jsonl`. Inspect the first flagged event for each run. A jump during overflow points to the insertion remainder or drop path. A jump only after a reload points to the save and restore path. A commit and a refund on the same run can be flagged even when the final item count is correct.

### Trace format v1

Each line is one checkpoint. See the example files for complete records. A file may contain multiple interleaved runs. Sequence numbers start at 1 and increase by one per run.

| Field | Value |
| --- | --- |
| `schema` | `1` |
| `run`, `event` | Identifiers of 1 to 128 characters. Use letters, numbers, underscores, dots, colons or hyphens, starting with a letter or number. |
| `seq`, `mark` | Sequence number and `begin`, `checkpoint` or `end`. |
| `phase` | `open`, `committed`, `cancelled` or `standalone` for a storage-only test. |
| `units` | Observed integer count for each of the 12 areas listed below. |
| `commits`, `refunds` | Cumulative executions of the logical settlement paths. Count a successful commit once even if it splits between inventory and overflow. Count duplicate executions when they actually occur. |
| `control_units` | Count of server-side Accept control units outside the trade GUI. |
| `expect` | On `begin`, the planned `outcome` and `transfer` from A to B if committed. A standalone test uses `transfer: 0`. An optional `final_units` object specifies exact final counts for selected areas. |
| `votes` | Optional `revision`, `a` and `b`, where each player value is their confirmed revision or `null`. Capture the actual votes used to authorize a commit before clearing the session. The stale-vote check runs on committed records with this field. |

| Areas | What to count |
| --- | --- |
| `a_inventory`, `b_inventory` | Tagged paper in server-side player inventory slots. |
| `a_cursor`, `b_cursor` | Tagged paper on each server-side cursor. |
| `a_backpack`, `b_backpack` | Tagged paper in the authoritative backpack store. |
| `a_ground`, `b_ground`, `ground_unknown` | Tagged units in item entities by assigned owner or unknown ownership. |
| `a_pending`, `b_pending` | Tagged paper in an undelivered and still claimable refund or delivery for that player. |
| `escrow` | The tagged offer reserved by an open trade. The baseline and settled states have empty escrow. |

Use zero only for an area you observed to be empty or one that is absent from the test setup. Count pending units toward ownership. To require a completed handoff, set the appropriate pending area to zero in `expect.final_units`.

| Exit code | Meaning |
| --- | --- |
| `0` | The supplied checkpoints passed the applicable checks. |
| `1` | An invariant failed. |
| `2` | The file or input format is invalid. |
| `3` | More evidence is needed to resolve the run, such as an end checkpoint or drop ownership. |

### Java writer for a staging backend

Copy `server/TraceWriter.java` into your Java source tree under `tradecheck/server`. Create one writer per run and call `begin`, `checkpoint` and `end` with snapshots from your trade and backpack handlers. The writer serializes the fields above. Supply the real item and control counts from your server code.

Capture counts where the backend provides a consistent view and preserve checkpoint order when writing them. The snapshots copy their maps, so a staging plugin can enqueue them to a single file writer. Attach the capture at the trade handler's confirmed delivery or refund boundary so the trace records completed effects.

To check the sample writer on a JDK 21 installation:

```powershell
mkdir build
javac -Xlint:all -d build server/TraceWriter.java server/TraceExample.java
java -cp build tradecheck.server.TraceExample | py -m tradecheck check -
```

## API references

- Paper's inventory insertion API fills eligible stacks and returns the part that did not fit. Build overflow from those returned amounts and keep an independent copy if you need the original amount for comparison. [Inventory.addItem](https://jd.papermc.io/paper/1.21.11/org/bukkit/inventory/Inventory.html#addItem(org.bukkit.inventory.ItemStack...))
- The captured Fabric screen ID `class_476` maps to `GenericContainerScreen`. For control-slot protection, review both click and drag handling and the slots each action can affect. [Yarn screen mapping](https://maven.fabricmc.net/docs/yarn-1.21.11%2Bbuild.4/net/minecraft/client/gui/screen/ingame/GenericContainerScreen.html) · [Paper click event](https://jd.papermc.io/paper/1.21.11/org/bukkit/event/inventory/InventoryClickEvent.html) · [Paper drag event](https://jd.papermc.io/paper/1.21.11/org/bukkit/event/inventory/InventoryDragEvent.html)
- Close, quit, and pickup are useful capture points around the custom handlers. Read the observed result after the operation settles. [Close event](https://jd.papermc.io/paper/1.21.11/org/bukkit/event/inventory/InventoryCloseEvent.html) · [Quit event](https://jd.papermc.io/paper/1.21.11/org/bukkit/event/player/PlayerQuitEvent.html) · [Pickup event](https://jd.papermc.io/paper/1.21.11/org/bukkit/event/entity/EntityPickupItemEvent.html)
- For a delivery that can retry after interruption, keep a stable operation ID and coordinate durable recording with the delivery effect. [AWS Builders' Library on safe retries](https://aws.amazon.com/builders-library/making-retries-safe-with-idempotent-APIs/)

