import io
import json
import unittest
from contextlib import redirect_stderr, redirect_stdout
from dataclasses import replace
from itertools import permutations
from pathlib import Path
from tempfile import TemporaryDirectory

from tradecheck.__main__ import main
from tradecheck.lab import CASES, TradeLab, simulate
from tradecheck.trace import Expectation, TraceFormatError, Votes, audit, read_jsonl


def changed_units(snapshot, **units):
    return replace(snapshot, units={**snapshot.units, **units})


def codes(result):
    return {finding.code for finding in result.findings}


class LabTests(unittest.TestCase):
    def test_every_case_round_trips_and_passes(self):
        for name in CASES:
            with self.subTest(name=name):
                records = simulate(name)
                decoded = read_jsonl(record.to_json() for record in records)
                self.assertEqual(decoded, records)
                result, = audit(decoded)
                self.assertEqual(result.status, "PASS", result.findings)

    def test_partial_overflow_counts_units_instead_of_drops(self):
        result, = audit(simulate("partial-overflow"))
        self.assertEqual(result.start_total, 70)
        self.assertEqual(result.final.units["b_inventory"], 64)
        self.assertEqual(result.final.units["b_ground"], 6)
        self.assertEqual(result.final.total, 70)

    def test_offer_revision_blocks_old_vote(self):
        records = simulate("offer-revision")
        rejected = next(record for record in records if record.event == "a_confirm_stale")
        self.assertEqual(rejected.phase, "open")
        self.assertEqual(rejected.votes, Votes(2, None, 2))
        self.assertEqual(records[-1].votes, Votes(2, 2, 2))

    def test_every_ordering_of_last_confirm_close_and_quit(self):
        for order in permutations(("confirm", "close", "quit")):
            with self.subTest(order=order):
                outcome = "committed" if order[0] == "confirm" else "cancelled"
                lab = TradeLab("ordering", Expectation(outcome, 1))
                lab.offer(1)
                lab.confirm("a")
                for event in order:
                    if event == "confirm":
                        lab.confirm("b")
                    else:
                        lab.close(event)
                result, = audit(lab.end())
                self.assertEqual(result.status, "PASS", result.findings)
                self.assertEqual(result.final.commits + result.final.refunds, 1)
                self.assertEqual(result.final.owned_by("b"), int(outcome == "committed"))

    def test_retry_consumes_pending_once(self):
        records = simulate("delivery-retry")
        failed = next(record for record in records if record.event == "delivery_attempt_failed")
        retried = next(record for record in records if record.event == "retry")
        again = next(record for record in records if record.event == "retry_again")
        self.assertEqual(failed.units["b_pending"], 1)
        self.assertEqual(retried.units["b_pending"], 0)
        self.assertEqual(retried.units["b_inventory"], 1)
        self.assertEqual(again.units, retried.units)


class AuditTests(unittest.TestCase):
    def test_reports_first_bad_overflow_checkpoint(self):
        records = simulate("partial-overflow")
        first_bad = next(index for index, record in enumerate(records) if record.event == "delivery_overflow")
        for index in range(first_bad, len(records)):
            records[index] = changed_units(records[index], b_ground=10)
        result, = audit(records)
        first = result.findings[0]
        self.assertEqual(result.status, "FAIL")
        self.assertEqual(result.final.total, 74)
        self.assertEqual((first.seq, first.event, first.code), (
            first_bad + 1, "delivery_overflow", "DUPLICATE_UNITS",
        ))
        self.assertIn("(+4)", first.message)

    def test_reports_missing_units(self):
        records = simulate("normal")
        records[-1] = changed_units(records[-1], b_inventory=0)
        result, = audit(records)
        self.assertIn("MISSING_UNITS", codes(result))

    def test_reports_backpack_duplicate_even_if_it_disappears_by_end(self):
        records = simulate("backpack-reload")
        reload_at = next(index for index, record in enumerate(records) if record.event == "backpack_reload")
        records[reload_at] = changed_units(records[reload_at], a_inventory=1)
        result, = audit(records)
        self.assertEqual(result.final.total, 1)
        self.assertIn("DUPLICATE_UNITS", codes(result))

    def test_reports_conserved_paper_with_wrong_owner(self):
        records = simulate("normal")
        records[-1] = changed_units(records[-1], a_inventory=1, b_inventory=0)
        result, = audit(records)
        self.assertEqual(result.final.total, result.start_total)
        self.assertIn("WRONG_OWNER", codes(result))

    def test_reports_wrong_destination_with_correct_owner(self):
        records = simulate("normal")
        records[-1] = changed_units(records[-1], b_inventory=0, b_backpack=1)
        result, = audit(records)
        self.assertEqual(codes(result), {"WRONG_DESTINATION"})

    def test_reports_double_settlement_without_extra_items(self):
        records = simulate("normal")
        records[-1] = replace(records[-1], refunds=1)
        result, = audit(records)
        self.assertEqual(codes(result), {"DOUBLE_SETTLEMENT"})

    def test_reports_stale_vote_on_commit(self):
        records = simulate("offer-revision")
        records[-1] = replace(records[-1], votes=Votes(2, 1, 2))
        result, = audit(records)
        self.assertEqual(codes(result), {"STALE_ACCEPTANCE"})

    def test_counts_accept_icon_separately(self):
        records = simulate("normal")
        records[1] = replace(records[1], control_units=1)
        result, = audit(records)
        self.assertEqual(codes(result), {"GUI_CONTROL_ESCAPED"})

    def test_unknown_ground_ownership_is_inconclusive(self):
        records = simulate("full-overflow")
        records[0] = replace(records[0], expect=Expectation("committed", 1))
        records[-1] = changed_units(records[-1], b_ground=0, ground_unknown=1)
        result, = audit(records)
        self.assertEqual(result.status, "INCONCLUSIVE")
        self.assertEqual(codes(result), {"OWNER_UNKNOWN"})

    def test_requires_begin_end_and_contiguous_sequence(self):
        records = simulate("normal")
        for partial, finding in (
            (records[:-1], "MISSING_END"),
            (records[1:], "MISSING_BEGIN"),
            (records[:1] + records[2:], "SEQUENCE_GAP"),
        ):
            with self.subTest(finding=finding):
                result, = audit(partial)
                self.assertEqual(result.status, "INCONCLUSIVE")
                self.assertIn(finding, codes(result))

    def test_can_check_interleaved_runs(self):
        normal = simulate("normal")
        overflow = simulate("partial-overflow")
        results = audit([normal[0], overflow[0], *normal[1:], *overflow[1:]])
        self.assertEqual([(result.run, result.status) for result in results], [
            ("normal", "PASS"), ("partial-overflow", "PASS"),
        ])


class InputTests(unittest.TestCase):
    def test_invalid_count_types_and_missing_areas_are_rejected(self):
        for value in (True, -1, 1.5, "1", None):
            with self.subTest(value=value):
                payload = json.loads(simulate("normal")[0].to_json())
                payload["units"]["a_inventory"] = value
                with self.assertRaisesRegex(TraceFormatError, r"line 1: units\.a_inventory"):
                    read_jsonl([json.dumps(payload)])
        payload = json.loads(simulate("normal")[0].to_json())
        del payload["units"]["b_backpack"]
        with self.assertRaisesRegex(TraceFormatError, r"line 2: units is missing b_backpack"):
            read_jsonl(["\n", json.dumps(payload)])

    def test_rejects_duplicate_keys_and_empty_input(self):
        with self.assertRaisesRegex(TraceFormatError, "duplicate JSON key"):
            read_jsonl(['{"schema":1,"schema":1}'])
        with self.assertRaisesRegex(TraceFormatError, "no checkpoints"):
            read_jsonl(["\n"])

    def test_cli_exports_and_checks_json(self):
        with TemporaryDirectory() as directory:
            path = Path(directory, "trace.jsonl")
            with redirect_stdout(io.StringIO()):
                self.assertEqual(main(["simulate", "partial-overflow", "--out", str(path)]), 0)
            output = io.StringIO()
            with redirect_stdout(output):
                self.assertEqual(main(["check", str(path), "--json"]), 0)
            result, = json.loads(output.getvalue())
            self.assertEqual(result["units"]["b_ground"], 6)

    def test_cli_exit_codes(self):
        records = simulate("normal")
        with TemporaryDirectory() as directory:
            path = Path(directory, "trace.jsonl")
            with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                path.write_text("invalid", encoding="utf-8")
                self.assertEqual(main(["check", str(path)]), 2)
                path.write_text("\n".join(record.to_json() for record in records[:-1]), encoding="utf-8")
                self.assertEqual(main(["check", str(path)]), 3)
                records[-1] = changed_units(records[-1], b_inventory=2)
                path.write_text("\n".join(record.to_json() for record in records), encoding="utf-8")
                self.assertEqual(main(["check", str(path)]), 1)


if __name__ == "__main__":
    unittest.main()
