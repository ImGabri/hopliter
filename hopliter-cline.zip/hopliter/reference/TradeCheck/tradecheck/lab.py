"""Deterministic fixtures for one batch of tagged items."""

from __future__ import annotations

import json
from collections.abc import Callable
from dataclasses import dataclass

from .trace import AREAS, Expectation, Snapshot, Votes


class TradeLab:
    def __init__(
        self,
        run: str,
        expected: Expectation,
        *,
        a_units: int = 1,
        b_units: int = 0,
        b_capacity: int = 64,
        defer_delivery: bool = False,
    ) -> None:
        self.run = run
        self.expected = expected
        self.phase = "standalone" if expected.outcome == "standalone" else "open"
        self.units = dict.fromkeys(AREAS, 0)
        self.units["a_inventory"] = a_units
        self.units["b_inventory"] = b_units
        self.capacity = {"a_inventory": 64, "b_inventory": b_capacity, "a_backpack": 64, "b_backpack": 64}
        self.defer_delivery = defer_delivery
        self.revision = 0
        self.votes: dict[str, int | None] = {"a": None, "b": None}
        self.commits = 0
        self.refunds = 0
        self.records: list[Snapshot] = []
        self._record("baseline", mark="begin")

    def _record(self, event: str, *, mark: str = "checkpoint") -> None:
        self.records.append(Snapshot(
            run=self.run,
            seq=len(self.records) + 1,
            mark=mark,
            event=event,
            phase=self.phase,
            units=self.units.copy(),
            commits=self.commits,
            refunds=self.refunds,
            expect=self.expected if mark == "begin" else None,
            votes=Votes(self.revision, self.votes["a"], self.votes["b"]) if self.phase != "standalone" else None,
        ))

    def _move(self, source: str, destination: str, amount: int) -> None:
        if not 0 <= amount <= self.units[source]:
            raise ValueError(f"cannot move {amount} units out of {source}")
        self.units[source] -= amount
        self.units[destination] += amount

    def offer(self, amount: int) -> None:
        if self.phase != "open" or amount < 0:
            raise ValueError("offer requires an open trade and a nonnegative amount")
        difference = amount - self.units["escrow"]
        if difference >= 0:
            self._move("a_inventory", "escrow", difference)
        else:
            self._move("escrow", "a_inventory", -difference)
        self.revision += 1
        self.votes = {"a": None, "b": None}
        self._record("offer_changed")

    def confirm(self, player: str, revision: int | None = None) -> None:
        if player not in self.votes:
            raise ValueError("confirm requires player a or b")
        if self.phase != "open":
            self._record(f"{player}_confirm_closed")
            return
        if revision is not None and revision != self.revision:
            self._record(f"{player}_confirm_stale")
            return
        self.votes[player] = self.revision
        self._record(f"{player}_confirm")
        if all(vote == self.revision for vote in self.votes.values()):
            self.phase = "committed"
            self.commits += 1
            self._move("escrow", "b_pending", self.units["escrow"])
            self._record("commit")
            if not self.defer_delivery:
                self.deliver_pending("b", "delivery")

    def close(self, event: str) -> None:
        if self.phase != "open":
            self._record(f"{event}_after_settlement")
            return
        self.phase = "cancelled"
        self.refunds += 1
        self._move("escrow", "a_pending", self.units["escrow"])
        self._record(event)
        self.deliver_pending("a", "refund")

    def deliver_pending(self, player: str, event: str) -> None:
        source = f"{player}_pending"
        inventory = f"{player}_inventory"
        requested = self.units[source]
        fit = min(requested, self.capacity[inventory] - self.units[inventory])
        self._move(source, inventory, fit)
        self._move(source, f"{player}_ground", requested - fit)
        self._record(f"{event}_overflow" if requested > fit else event)

    def fill_sender_inventory(self) -> None:
        self.capacity["a_inventory"] = self.units["a_inventory"]
        self._record("sender_inventory_full")

    def pickup_into_backpack(self) -> None:
        fit = min(self.units["b_ground"], self.capacity["b_backpack"] - self.units["b_backpack"])
        self._move("b_ground", "b_backpack", fit)
        self._record("backpack_pickup")

    def backpack_roundtrip(self) -> None:
        self._move("a_inventory", "a_backpack", self.units["a_inventory"])
        self._record("backpack_deposit")
        persisted = json.dumps(self.units)
        self.units = json.loads(persisted)
        self._record("backpack_reload")

    def end(self) -> list[Snapshot]:
        self._record("final", mark="end")
        return self.records


@dataclass(frozen=True)
class Case:
    description: str
    expected: Expectation
    exercise: Callable[[TradeLab], None]
    a_units: int = 1
    b_units: int = 0
    b_capacity: int = 64
    defer_delivery: bool = False


def _complete(lab: TradeLab) -> None:
    lab.offer(lab.expected.transfer)
    lab.confirm("a")
    lab.confirm("b")


def _full_refund(lab: TradeLab) -> None:
    lab.offer(lab.expected.transfer)
    lab.fill_sender_inventory()
    lab.close("close")
    lab.close("quit")


def _late_confirm(lab: TradeLab) -> None:
    lab.offer(lab.expected.transfer)
    lab.confirm("a")
    lab.close("quit")
    lab.confirm("b")
    lab.close("close")


def _close_after_commit(lab: TradeLab) -> None:
    _complete(lab)
    lab.close("close")
    lab.close("quit")
    lab.confirm("a")


def _changed_offer(lab: TradeLab) -> None:
    lab.offer(3)
    previous_revision = lab.revision
    lab.confirm("a")
    lab.offer(2)
    lab.confirm("b")
    lab.confirm("a", previous_revision)
    lab.confirm("a")


def _backpack_pickup(lab: TradeLab) -> None:
    _complete(lab)
    lab.pickup_into_backpack()


def _delivery_retry(lab: TradeLab) -> None:
    _complete(lab)
    # The first attempt makes no delivery. A retry consumes the pending units.
    lab._record("delivery_attempt_failed")
    lab.deliver_pending("b", "retry")
    lab.deliver_pending("b", "retry_again")


CASES = {
    "normal": Case(
        "Both players confirm and B has room.",
        Expectation("committed", 1, {"b_inventory": 1, "b_ground": 0}), _complete,
    ),
    "full-overflow": Case(
        "B has no room for the tagged paper.",
        Expectation("committed", 1, {"b_inventory": 0, "b_ground": 1}), _complete, b_capacity=0,
    ),
    "partial-overflow": Case(
        "A offers 10, B's matching stack has space for 4, and 6 must overflow.",
        Expectation("committed", 10, {"b_inventory": 64, "b_ground": 6}), _complete,
        a_units=10, b_units=60,
    ),
    "full-refund": Case(
        "A fills their inventory after offering the paper. Close and quit refund once.",
        Expectation("cancelled", 1, {"a_inventory": 0, "a_ground": 1}), _full_refund,
    ),
    "late-confirm": Case(
        "A confirm arrives after the trade was cancelled.",
        Expectation("cancelled", 1, {"a_inventory": 1, "b_inventory": 0}), _late_confirm,
    ),
    "close-after-commit": Case(
        "Close, quit and an extra confirm follow successful delivery.",
        Expectation("committed", 1, {"a_inventory": 0, "b_inventory": 1}), _close_after_commit,
    ),
    "offer-revision": Case(
        "Changing the offer clears the votes and requires a fresh confirmation.",
        Expectation("committed", 2, {"a_inventory": 1, "b_inventory": 2}), _changed_offer, a_units=3,
    ),
    "backpack-pickup": Case(
        "B collects the overflow into a backpack while inventory is full.",
        Expectation("committed", 1, {"b_ground": 0, "b_backpack": 1}), _backpack_pickup, b_capacity=0,
    ),
    "backpack-reload": Case(
        "A saves and reloads a backpack deposit independently of a trade.",
        Expectation("standalone", 0, {"a_inventory": 0, "a_backpack": 1}), TradeLab.backpack_roundtrip,
    ),
    "delivery-retry": Case(
        "Deferred delivery retries after failure and again after successful delivery.",
        Expectation("committed", 1, {"b_inventory": 1, "b_pending": 0}), _delivery_retry, defer_delivery=True,
    ),
}


def simulate(name: str) -> list[Snapshot]:
    case = CASES[name]
    lab = TradeLab(
        name, case.expected, a_units=case.a_units, b_units=case.b_units,
        b_capacity=case.b_capacity, defer_delivery=case.defer_delivery,
    )
    case.exercise(lab)
    return lab.end()
