"""Version 1 checkpoint format and item-conservation audit."""

from __future__ import annotations

import json
import re
from collections.abc import Iterable
from dataclasses import asdict, dataclass, field

AREAS = (
    "a_inventory", "b_inventory",
    "a_cursor", "b_cursor",
    "a_backpack", "b_backpack",
    "a_ground", "b_ground", "ground_unknown",
    "a_pending", "b_pending",
    "escrow",
)
PHASE_COUNTS = {
    "open": (0, 0),
    "committed": (1, 0),
    "cancelled": (0, 1),
    "standalone": (0, 0),
}
TERMINAL = {"committed", "cancelled", "standalone"}
LABEL = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}")


@dataclass(frozen=True)
class Expectation:
    outcome: str
    transfer: int
    final_units: dict[str, int] = field(default_factory=dict)


@dataclass(frozen=True)
class Votes:
    revision: int
    a: int | None
    b: int | None


@dataclass(frozen=True)
class Snapshot:
    run: str
    seq: int
    mark: str
    event: str
    phase: str
    units: dict[str, int]
    commits: int = 0
    refunds: int = 0
    control_units: int = 0
    expect: Expectation | None = None
    votes: Votes | None = None

    @property
    def total(self) -> int:
        return sum(self.units.values())

    def owned_by(self, player: str) -> int:
        return sum(amount for area, amount in self.units.items() if area.startswith(f"{player}_"))

    def to_json(self) -> str:
        payload = {key: value for key, value in asdict(self).items() if value is not None}
        return json.dumps({"schema": 1, **payload}, separators=(",", ":"))


@dataclass(frozen=True)
class Finding:
    seq: int
    event: str
    code: str
    message: str
    incomplete: bool = False


@dataclass
class RunResult:
    run: str
    start_total: int | None
    final: Snapshot
    findings: list[Finding] = field(default_factory=list)

    @property
    def status(self) -> str:
        if any(not finding.incomplete for finding in self.findings):
            return "FAIL"
        return "INCONCLUSIVE" if self.findings else "PASS"

    def add(self, record: Snapshot, code: str, message: str, *, incomplete: bool = False) -> None:
        self.findings.append(Finding(record.seq, record.event, code, message, incomplete))

    def to_dict(self) -> dict:
        return {
            "run": self.run,
            "status": self.status,
            "start_total": self.start_total,
            "last_total": self.final.total,
            "phase": self.final.phase,
            "units": self.final.units,
            "findings": [asdict(finding) for finding in self.findings],
        }


class TraceFormatError(ValueError):
    """An input line cannot be interpreted as a complete v1 checkpoint."""


def _fields(value: object, required: set[str], optional: set[str], label: str) -> dict:
    if not isinstance(value, dict):
        raise TraceFormatError(f"{label} must be an object")
    missing = required - value.keys()
    extra = value.keys() - required - optional
    if missing:
        raise TraceFormatError(f"{label} is missing {', '.join(sorted(missing))}")
    if extra:
        raise TraceFormatError(f"{label} has unknown fields {', '.join(sorted(extra))}")
    return value


def _integer(value: object, label: str, minimum: int = 0) -> int:
    if type(value) is not int or value < minimum:
        raise TraceFormatError(f"{label} must be an integer >= {minimum}")
    return value


def _enum(value: object, choices: Iterable[str], label: str) -> str:
    if not isinstance(value, str) or value not in choices:
        raise TraceFormatError(f"{label} must be one of {', '.join(sorted(choices))}")
    return value


def _label(value: object, field_name: str) -> str:
    if not isinstance(value, str) or not LABEL.fullmatch(value):
        raise TraceFormatError(f"{field_name} must be a 1-128 character identifier")
    return value


def _unique_object(pairs: list[tuple[str, object]]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise TraceFormatError(f"duplicate JSON key {key!r}")
        result[key] = value
    return result


def _counts(value: object, label: str, *, complete: bool) -> dict[str, int]:
    required = set(AREAS) if complete else set()
    optional = set() if complete else set(AREAS)
    fields = _fields(value, required, optional, label)
    return {area: _integer(amount, f"{label}.{area}") for area, amount in fields.items()}


def _read_snapshot(raw: object) -> Snapshot:
    data = _fields(
        raw,
        {"schema", "run", "seq", "mark", "event", "phase", "units", "commits", "refunds", "control_units"},
        {"expect", "votes"},
        "checkpoint",
    )
    if _integer(data["schema"], "schema", 1) != 1:
        raise TraceFormatError("unsupported schema version")
    mark = _enum(data["mark"], {"begin", "checkpoint", "end"}, "mark")
    expect = None
    if mark == "begin":
        fields = _fields(data.get("expect"), {"outcome", "transfer"}, {"final_units"}, "expect")
        expect = Expectation(
            _enum(fields["outcome"], TERMINAL, "expect.outcome"),
            _integer(fields["transfer"], "expect.transfer"),
            _counts(fields.get("final_units", {}), "expect.final_units", complete=False),
        )
        if expect.outcome == "standalone" and expect.transfer:
            raise TraceFormatError("a standalone run must have expect.transfer=0")
    elif "expect" in data:
        raise TraceFormatError("expect belongs on the begin checkpoint")

    votes = None
    if "votes" in data:
        fields = _fields(data["votes"], {"revision", "a", "b"}, set(), "votes")
        votes = Votes(
            _integer(fields["revision"], "votes.revision"),
            None if fields["a"] is None else _integer(fields["a"], "votes.a"),
            None if fields["b"] is None else _integer(fields["b"], "votes.b"),
        )

    return Snapshot(
        run=_label(data["run"], "run"),
        seq=_integer(data["seq"], "seq", 1),
        mark=mark,
        event=_label(data["event"], "event"),
        phase=_enum(data["phase"], PHASE_COUNTS, "phase"),
        units=_counts(data["units"], "units", complete=True),
        commits=_integer(data["commits"], "commits"),
        refunds=_integer(data["refunds"], "refunds"),
        control_units=_integer(data["control_units"], "control_units"),
        expect=expect,
        votes=votes,
    )


def read_jsonl(lines: Iterable[str]) -> list[Snapshot]:
    records = []
    for number, line in enumerate(lines, 1):
        if not line.strip():
            continue
        try:
            raw = json.loads(line, object_pairs_hook=_unique_object)
            records.append(_read_snapshot(raw))
        except (ValueError, RecursionError) as exc:
            raise TraceFormatError(f"line {number}: {exc}") from exc
    if not records:
        raise TraceFormatError("input contains no checkpoints")
    return records


def audit(records: Iterable[Snapshot]) -> list[RunResult]:
    by_run: dict[str, list[Snapshot]] = {}
    for record in records:
        by_run.setdefault(record.run, []).append(record)
    return [_audit_run(run) for run in by_run.values()]


def _audit_run(records: list[Snapshot]) -> RunResult:
    first, last = records[0], records[-1]
    baseline = first if first.mark == "begin" and first.expect is not None else None
    result = RunResult(first.run, baseline.total if baseline else None, last)
    if baseline is None:
        result.add(first, "MISSING_BEGIN", "Capture the baseline before any item moves.", incomplete=True)
    if last.mark != "end":
        result.add(last, "MISSING_END", "Capture a final checkpoint after the run settles.", incomplete=True)

    previous = None
    gap_reported = False
    for index, record in enumerate(records, 1):
        if record.seq != index and not gap_reported:
            result.add(record, "SEQUENCE_GAP", f"Expected checkpoint {index}.", incomplete=True)
            gap_reported = True
        if (index != 1 and record.mark == "begin") or (index != len(records) and record.mark == "end"):
            result.add(record, "MISPLACED_BOUNDARY", "Each run needs one begin and one end.", incomplete=True)

        if baseline is not None and record.total != baseline.total:
            delta = record.total - baseline.total
            code = "DUPLICATE_UNITS" if delta > 0 else "MISSING_UNITS"
            result.add(record, code, f"Expected {baseline.total} tagged units, found {record.total} ({delta:+d}).")
        if record.control_units:
            result.add(record, "GUI_CONTROL_ESCAPED", f"Found {record.control_units} control unit(s) outside the GUI.")

        if record.commits + record.refunds > 1:
            result.add(record, "DOUBLE_SETTLEMENT", f"Recorded {record.commits} commit(s) and {record.refunds} refund(s).")
        elif (record.commits, record.refunds) != PHASE_COUNTS[record.phase]:
            result.add(record, "STATE_COUNTER_MISMATCH", f"Settlement counts disagree with {record.phase}.")

        if previous and previous.phase in TERMINAL and record.phase != previous.phase:
            result.add(record, "PHASE_CHANGED", f"Phase changed from {previous.phase} to {record.phase}.")
        if record.phase in TERMINAL and record.units["escrow"]:
            result.add(record, "ESCROW_REMAINS", f"Found {record.units['escrow']} units in escrow after settlement.")
        if record.phase == "committed" and record.votes is not None:
            if record.votes.a != record.votes.revision or record.votes.b != record.votes.revision:
                result.add(record, "STALE_ACCEPTANCE", "Both players must accept the committed offer revision.")
        previous = record

    if baseline is not None and last.mark == "end":
        _check_outcome(baseline, last, result)
    return result


def _check_outcome(first: Snapshot, last: Snapshot, result: RunResult) -> None:
    expectation = first.expect
    assert expectation is not None
    initial_phase = "standalone" if expectation.outcome == "standalone" else "open"
    if first.phase != initial_phase or first.units["escrow"] or first.units["ground_unknown"]:
        result.add(
            first,
            "INVALID_BASELINE",
            f"Start in {initial_phase} with assigned ownership and empty escrow.",
            incomplete=True,
        )
        return
    if last.phase != expectation.outcome:
        result.add(last, "WRONG_OUTCOME", f"Expected {expectation.outcome}, observed {last.phase}.")
        return

    for area, expected in expectation.final_units.items():
        actual = last.units[area]
        if actual != expected:
            result.add(last, "WRONG_DESTINATION", f"{area} expected {expected}, found {actual}.")

    transfer = expectation.transfer if last.phase == "committed" else 0
    expected_a = first.owned_by("a") - transfer
    expected_b = first.owned_by("b") + transfer
    if expected_a < 0:
        result.add(first, "INVALID_TRANSFER", "Expected transfer exceeds A's baseline units.", incomplete=True)
        return
    if last.total != first.total or last.units["escrow"]:
        return
    actual_a, actual_b = last.owned_by("a"), last.owned_by("b")
    if actual_a > expected_a or actual_b > expected_b:
        result.add(last, "WRONG_OWNER", f"Expected A={expected_a}, B={expected_b}; assigned A={actual_a}, B={actual_b}.")
    elif last.units["ground_unknown"]:
        result.add(
            last,
            "OWNER_UNKNOWN",
            f"Assign the {last.units['ground_unknown']} ground units to an owner or check after pickup.",
            incomplete=True,
        )
