"""Command-line entry point. Run with python -m tradecheck."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .lab import CASES, simulate
from .trace import RunResult, TraceFormatError, audit, read_jsonl

EXIT_STATUS = {"PASS": 0, "FAIL": 1, "INCONCLUSIVE": 3}


def report(results: list[RunResult], *, as_json: bool = False) -> int:
    if as_json:
        print(json.dumps([result.to_dict() for result in results], indent=2))
    else:
        for result in results:
            start = "unknown" if result.start_total is None else str(result.start_total)
            print(f"[{result.status}] {result.run}: {start} -> {result.final.total} units ({result.final.phase})")
            units = ", ".join(f"{area}={amount}" for area, amount in result.final.units.items() if amount)
            if units:
                print(f"  Last checkpoint: {units}")
            for finding in result.findings:
                print(f"  #{finding.seq} {finding.event} [{finding.code}] {finding.message}")
    statuses = {result.status for result in results}
    if "FAIL" in statuses:
        return EXIT_STATUS["FAIL"]
    if "INCONCLUSIVE" in statuses:
        return EXIT_STATUS["INCONCLUSIVE"]
    return EXIT_STATUS["PASS"]


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run local trade cases or audit exported server checkpoints.")
    subcommands = parser.add_subparsers(dest="command", required=True)
    subcommands.add_parser("list", help="show available local cases")
    subcommands.add_parser("suite", help="run and audit all local cases")
    simulate_parser = subcommands.add_parser("simulate", help="run and audit one local case")
    simulate_parser.add_argument("case", choices=CASES)
    simulate_parser.add_argument("--out", type=Path, help="write the case checkpoints as JSON Lines")
    check_parser = subcommands.add_parser("check", help="audit JSON Lines checkpoints")
    check_parser.add_argument("trace", help="trace file, or - for standard input")
    check_parser.add_argument("--json", action="store_true", help="return structured findings")
    args = parser.parse_args(argv)

    try:
        if args.command == "list":
            for name, case in CASES.items():
                print(f"{name:20} {case.description}")
            return 0
        if args.command == "suite":
            return report(audit(record for name in CASES for record in simulate(name)))
        if args.command == "simulate":
            records = simulate(args.case)
            if args.out is not None:
                args.out.write_text("".join(f"{record.to_json()}\n" for record in records), encoding="utf-8")
            return report(audit(records))
        if args.trace == "-":
            records = read_jsonl(sys.stdin)
        else:
            with Path(args.trace).open(encoding="utf-8-sig") as trace:
                records = read_jsonl(trace)
        return report(audit(records), as_json=args.json)
    except (OSError, TraceFormatError, UnicodeError) as exc:
        print(f"tradecheck: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
