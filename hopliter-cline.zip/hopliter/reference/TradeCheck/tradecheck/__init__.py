"""Offline trade and backpack regression checks."""
