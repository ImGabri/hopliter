package tradecheck.server;

import java.io.IOException;
import java.io.Writer;
import java.util.EnumMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.StringJoiner;
import java.util.regex.Pattern;

/** Writes complete checkpoints from the caller's observed server state. */
public final class TraceWriter {
    private static final Pattern LABEL = Pattern.compile("[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}");

    public enum Area {
        A_INVENTORY, B_INVENTORY, A_CURSOR, B_CURSOR, A_BACKPACK, B_BACKPACK,
        A_GROUND, B_GROUND, GROUND_UNKNOWN, A_PENDING, B_PENDING, ESCROW
    }

    public enum Phase {
        OPEN, COMMITTED, CANCELLED, STANDALONE
    }

    public record Expectation(Phase outcome, int transfer, Map<Area, Integer> finalUnits) {
        public Expectation {
            Objects.requireNonNull(outcome, "outcome");
            if (outcome == Phase.OPEN || (outcome == Phase.STANDALONE && transfer != 0)) {
                throw new IllegalArgumentException("invalid expected outcome or standalone transfer");
            }
            nonnegative(transfer);
            finalUnits = checkedUnits(finalUnits);
        }
    }

    public record Votes(int revision, Integer a, Integer b) {
        public Votes {
            nonnegative(revision);
            if (a != null) {
                nonnegative(a);
            }
            if (b != null) {
                nonnegative(b);
            }
        }
    }

    public record Snapshot(
        Phase phase, Map<Area, Integer> units, int commits, int refunds, int controlUnits, Votes votes
    ) {
        public Snapshot {
            Objects.requireNonNull(phase, "phase");
            units = checkedUnits(units);
            if (units.size() != Area.values().length) {
                throw new IllegalArgumentException("snapshot must include all areas");
            }
            nonnegative(commits);
            nonnegative(refunds);
            nonnegative(controlUnits);
        }
    }

    private final Writer output;
    private final String run;
    private int sequence;
    private boolean ended;
    private boolean writeFailed;

    public TraceWriter(Writer output, String run) {
        this.output = Objects.requireNonNull(output, "output");
        this.run = label(run);
    }

    /** Use zeros for areas observed to be empty or absent from the test fixture. */
    public static EnumMap<Area, Integer> zeroUnits() {
        EnumMap<Area, Integer> result = new EnumMap<>(Area.class);
        for (Area area : Area.values()) {
            result.put(area, 0);
        }
        return result;
    }

    public synchronized void begin(String event, Snapshot snapshot, Expectation expectation) throws IOException {
        if (sequence != 0) {
            throw new IllegalStateException("run has already started");
        }
        emit("begin", event, snapshot, Objects.requireNonNull(expectation, "expectation"));
    }

    public synchronized void checkpoint(String event, Snapshot snapshot) throws IOException {
        requireActive();
        emit("checkpoint", event, snapshot, null);
    }

    public synchronized void end(String event, Snapshot snapshot) throws IOException {
        requireActive();
        emit("end", event, snapshot, null);
        ended = true;
    }

    private void requireActive() {
        if (sequence == 0 || ended) {
            throw new IllegalStateException("run is not active");
        }
    }

    private void emit(String mark, String event, Snapshot snapshot, Expectation expectation) throws IOException {
        if (writeFailed) {
            throw new IllegalStateException("a previous write failed");
        }
        StringBuilder json = new StringBuilder();
        json.append("{\"schema\":1,\"run\":\"").append(run)
            .append("\",\"seq\":").append(sequence + 1)
            .append(",\"mark\":\"").append(mark)
            .append("\",\"event\":\"").append(label(event))
            .append("\",\"phase\":\"").append(key(snapshot.phase()))
            .append("\",\"units\":").append(unitJson(snapshot.units()))
            .append(",\"commits\":").append(snapshot.commits())
            .append(",\"refunds\":").append(snapshot.refunds())
            .append(",\"control_units\":").append(snapshot.controlUnits());
        if (expectation != null) {
            json.append(",\"expect\":{\"outcome\":\"").append(key(expectation.outcome()))
                .append("\",\"transfer\":").append(expectation.transfer())
                .append(",\"final_units\":").append(unitJson(expectation.finalUnits())).append('}');
        }
        Votes votes = snapshot.votes();
        if (votes != null) {
            json.append(",\"votes\":{\"revision\":").append(votes.revision())
                .append(",\"a\":").append(votes.a())
                .append(",\"b\":").append(votes.b()).append('}');
        }
        json.append("}\n");
        synchronized (output) {
            try {
                output.write(json.toString());
                output.flush();
            } catch (IOException error) {
                writeFailed = true;
                throw error;
            }
        }
        sequence++;
    }

    private static Map<Area, Integer> checkedUnits(Map<Area, Integer> units) {
        Map<Area, Integer> copy = Map.copyOf(units);
        copy.values().forEach(TraceWriter::nonnegative);
        return copy;
    }

    private static String unitJson(Map<Area, Integer> units) {
        StringJoiner fields = new StringJoiner(",", "{", "}");
        for (Area area : Area.values()) {
            if (units.containsKey(area)) {
                fields.add("\"" + key(area) + "\":" + units.get(area));
            }
        }
        return fields.toString();
    }

    private static String key(Enum<?> value) {
        return value.name().toLowerCase(Locale.ROOT);
    }

    private static String label(String value) {
        if (!LABEL.matcher(value).matches()) {
            throw new IllegalArgumentException("expected a 1-128 character identifier");
        }
        return value;
    }

    private static void nonnegative(int value) {
        if (value < 0) {
            throw new IllegalArgumentException("expected a nonnegative count or revision");
        }
    }
}
