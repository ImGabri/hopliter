package tradecheck.server;

import static tradecheck.server.TraceWriter.Area.A_INVENTORY;
import static tradecheck.server.TraceWriter.Area.B_GROUND;
import static tradecheck.server.TraceWriter.Area.B_INVENTORY;
import static tradecheck.server.TraceWriter.Area.ESCROW;
import static tradecheck.server.TraceWriter.Phase.COMMITTED;
import static tradecheck.server.TraceWriter.Phase.OPEN;

import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import tradecheck.server.TraceWriter.Expectation;
import tradecheck.server.TraceWriter.Snapshot;
import tradecheck.server.TraceWriter.Votes;

/** Example fixture. A plugin supplies the same counts from real checkpoints. */
public final class TraceExample {
    public static void main(String[] args) throws Exception {
        var output = new BufferedWriter(new OutputStreamWriter(System.out, StandardCharsets.UTF_8));
        var trace = new TraceWriter(output, "java-partial-overflow");
        var units = TraceWriter.zeroUnits();
        units.put(A_INVENTORY, 10);
        units.put(B_INVENTORY, 60);
        trace.begin(
            "baseline", new Snapshot(OPEN, units, 0, 0, 0, new Votes(0, null, null)),
            new Expectation(COMMITTED, 10, Map.of(B_INVENTORY, 64, B_GROUND, 6))
        );

        units.put(A_INVENTORY, 0);
        units.put(ESCROW, 10);
        trace.checkpoint("offer_changed", new Snapshot(OPEN, units, 0, 0, 0, new Votes(1, null, null)));

        units.put(ESCROW, 0);
        units.put(B_INVENTORY, 64);
        units.put(B_GROUND, 6);
        var delivered = new Snapshot(COMMITTED, units, 1, 0, 0, new Votes(1, 1, 1));
        trace.checkpoint("delivery_overflow", delivered);
        trace.end("final", delivered);
    }
}
